#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE GPXTests
#include <boost/test/unit_test.hpp>

// Test files can be found in "gpx-tests/"

# GPS for Deliverable 3

Please watch the following [video](https://youtu.be/OYXyMyAzHRo)
